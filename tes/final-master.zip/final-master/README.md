# final
FINNALY BOT LINE PRANKBOTS

jika error ada tulisan seperti berikut
``` ~ no module anuanu ```
maka tinggal ketik pip3 install anuanu dan begitupun eror no module lainya dan mengatasinya dengan penginstalan yang sama

untuk titorial silahkan cek di channel youtube prankbots dibawah ini
# KLIK DIBAWAH INI
[![PrankBots](https://pa1.narvii.com/6842/70c57ecb549776bab0f78f1f6ee08c79bf9ed7bb_hq.gif "Prankbots")](https://bit.ly/2xbVxlh)

- ttd acil.
